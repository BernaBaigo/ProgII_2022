public class AttendanceList {
// ESTO NO VA
//    private int qAttendees;
//    private Attendees[] attendees;
//
//    public AttendanceList (int qAttendees,String aName, String aMail, int aPhoneNumber){
//        this.qAttendees = qAttendees;
//        this.attendees = new Attendees[this.qAttendees];
//
//        for (int i = 0; i < qAttendees; i++) {
//
//            this.attendees[i] = new Attendees(aName, aMail, aPhoneNumber); //No me cierra - Todos tendrían el mismo nombre???
//
//        }
//
//    }

}
