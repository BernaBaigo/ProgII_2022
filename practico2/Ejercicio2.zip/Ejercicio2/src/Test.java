import java.util.ArrayList;

public class Test {

    public static void main (String[] args){

        ArrayList <String> cars = new ArrayList<String>();
        cars.add("VW");
        cars.add("Fiat");
        cars.add("Volvo");

        System.out.println(cars);

    }
}
