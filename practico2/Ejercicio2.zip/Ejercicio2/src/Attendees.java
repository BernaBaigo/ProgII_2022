//public class Attendees {
//
//    private String aName;
//    private String aMail;
//    private int aPhoneNumber;
//
//    //CONSTRUCTOR
//    public Attendees(String aName, String aMail, int aPhoneNumber){
//        this.aName = aName;
//        this.aMail = aMail;
//        this.aPhoneNumber = aPhoneNumber;
//
//    }
//
//    //SETTERS & GETTERS
//    public String getaName() {
//        return aName;
//    }
//
//    public String getaMail() {
//        return aMail;
//    }
//
//    public int getaPhoneNumber() {
//        return aPhoneNumber;
//    }
//
//    public void setaName(String aName) {
//        this.aName = aName;
//    }
//
//    public void setaMail(String aMail) {
//        this.aMail = aMail;
//    }
//
//    public void setaPhoneNumber(int aPhoneNumber) {
//        this.aPhoneNumber = aPhoneNumber;
//    }
//}
